package voting

import org.h2.engine.User

class AdminController {


    def index() {
        if (session.u) {}
    }

    def AdminLogin() {
            Admin Username = Admin.findByUsernameAndPassword(params.Username, params.Password)

        if (Username) {
            session.u = Username.id
                session["Admin"]=Username
                redirect(action: "Create")

            } else {
                println "wrong USER-ID-&-PASSWORD"
                redirect(action: "index")
            }


    }
    def Create() {
        if (session.u) {
            def Voters = Voters.list()
            [Voters: Voters]
        }
    }
    def VoterUpdate(long id){
        if (session.u) {
            Voters c1 = Voters.get(id)

            if (c1) {
                [c1: c1]

            } else {
                println "wrong user-ID"
                redirect(action: "Create")

            }
        }
    }
    def VoterDelete(long id){
        if (session.u) {
            Voters c1 = Voters.findById(id)
            if (c1) {
                c1.delete(flush: true)
            } else {
                println "wrong user-ID- ${id}"
            }
            redirect(action: "Create")
        }
    }
    def VoterCreate() {
        if (session.u) {}
    }

    def VoterSave() {
        if (session.u) {
            Map a1 = [:]
            a1.name = params.name
            a1.collegeid = params.Collegeid
            a1.password = params.Password
            a1.p = 0
            a1.vp = 0
            a1.s = 0
            a1.js = 0
            Voters userinstance = new Voters(a1)
            userinstance.save()
            redirect(action: "VoterCreate")
        }
    }
    def Logout() {
        if (session.u) {
            session.invalidate()
            redirect(action: "index")

        }
    }



}
