package voting

class CandidateController {

    def index() {
        if (session.u) {}
    }

    def view() {
        if (session.u) {}
    }

    def President() {
        if (session.u) {}

    }

    def PresidentSave() {
        if (session.u) {
            Map p = [:]
            p.name1 = params.name1
            p.age1 = params.age1
            p.add1 = params.add1
            p.count = 0
            President c1 = new President(p)
            c1.save()
            redirect(action: "index")
        }
    }

    def deletePresident(long id) {
        if (session.u) {
            President c1 = President.findById(id)
            if (c1) {
                c1.delete(flush: true)
            } else {
                println "wrong user-ID- ${id}"
            }
            redirect(action: "ViewPresident")
        }
    }

    def updatePresident(long id) {
        if (session.u) {
            President c1 = President.get(id)
            if (c1) {
                c1.name1 = params.name1
                c1.age1 = params.age1
                c1.add1 = params.add1
                c1.save(flush: true)
                redirect(action: "ViewPresident")
            } else {
                println "wrong USER-ID-"
                redirect(action: "ViewPresident")
            }
        }
    }

    def ViewPresident() {
        if (session.u) {
            def userList = President.list()
            [President: userList]
        }
    }

    def ShowPresident(long id) {
        if (session.u) {
            President c1 = President.get(id)

            if (c1) {
                [c1: c1]

            } else {
                println "wrong user-ID"
                redirect(action: "index")

            }
        }
    }


    def VicePresident() {
        if (session.u){}
    }

    def VicePresidentSave() {
        if (session.u) {
            Map p = [:]
            p.name2 = params.name2
            p.age2 = params.age2
            p.add2 = params.add2
            p.count = 0
            VicePresident c2 = new VicePresident(p)
            c2.save()
            redirect(action: "index")
        }
    }

    def deleteVicePresident(long id) {
        if (session.u) {
            VicePresident c2 = VicePresident.findById(id)
            if (c2) {
                c2.delete(flush: true)
            } else {
                println "wrong user-ID- ${id}"
            }
            redirect(action: "ViewVicePresident")
        }
    }

    def updateVicePresident(long id) {
        if (session.u) {
            VicePresident c2 = VicePresident.get(id)
            if (c2) {
                c2.name2 = params.name2
                c2.age2 = params.age2
                c2.add2 = params.add2
                c2.save(flush: true)
                redirect(action: "ViewVicePresident")
            } else {
                println "wrong USER-ID-"
                redirect(action: "ViewVicePresident")
            }
        }
    }

    def ViewVicePresident() {
        if (session.u) {
            def userList = VicePresident.list()
            [VicePresident: userList]
        }
    }

    def ShowVicePresident(long id) {
        if (session.u) {
            VicePresident c2 = VicePresident.get(id)

            if (c2) {
                [c2: c2]

            } else {
                println "wrong user-ID"
                redirect(action: "index")
            }
        }
    }

    def Secretary() {
        if (session.u){}
    }

    def SecretarySave() {
        if (session.u) {
            Map p = [:]
            p.name3 = params.name3
            p.age3 = params.age3
            p.add3 = params.add3
            p.count = 0
            Secretary c3 = new Secretary(p)
            c3.save()
            redirect(action: "index")
        }
    }

    def deleteSecretary(long id) {
        if (session.u) {
            Secretary c3 = Secretary.findById(id)
            if (c3) {
                c3.delete(flush: true)
            } else {
                println "wrong user-ID- ${id}"
            }
            redirect(action: "ViewSecretary")
        }
    }

    def updateSecretary(long id) {
        if (session.u) {
            Secretary c3 = Secretary.get(id)
            if (c3) {
                c3.name3 = params.name3
                c3.age3 = params.age3
                c3.add3 = params.add3
                c3.save(flush: true)
                redirect(action: "ViewSecretary")
            } else {
                println "wrong USER-ID-"
                redirect(action: "ViewSecretary")
            }
        }
    }

    def ViewSecretary() {
        if (session.u) {
            def userList = Secretary.list()
            [Secretary: userList]
        }
    }

    def ShowSecretary(long id) {
        if (session.u) {
            Secretary c3 = Secretary.get(id)

            if (c3) {
                [c3: c3]

            } else {
                println "wrong user-ID"
                redirect(action: "index")
            }
        }
    }

    def JointSecretary() {
        if (session.u) {}
    }

    def JointSecretarySave() {
        if (session.u) {
            Map p = [:]
            p.name4 = params.name4
            p.age4 = params.age4
            p.add4 = params.add4
            p.count = 0
            JointSecretary c4 = new JointSecretary(p)
            c4.save()
            redirect(action: "index")
        }
    }

    def deleteJointSecretary(long id) {
        if (session.u) {
            JointSecretary c4 = JointSecretary.findById(id)
            if (c4) {
                c4.delete(flush: true)
            } else {
                println "wrong user-ID- ${id}"
            }
            redirect(action: "ViewJointSecretary")
        }
    }

    def updateJointSecretary(long id) {
        if (session.u) {
            JointSecretary c4 = JointSecretary.get(id)
            if (c4) {
                c4.name4 = params.name4
                c4.age4 = params.age4
                c4.add4 = params.add4
                c4.save(flush: true)
                redirect(action: "ViewJointSecretary")
            } else {
                println "wrong USER-ID-"
                redirect(action: "ViewJointSecretary")
            }
        }
    }

    def ViewJointSecretary() {
        if (session.u) {
            def userList = JointSecretary.list()
            [JointSecretary: userList]
        }
    }

    def ShowJointSecretary(long id) {
        if (session.u) {
            JointSecretary c4 = JointSecretary.get(id)

            if (c4) {
                [c4: c4]

            } else {
                println "wrong user-ID"
                redirect(action: "index")
            }
        }
    }

//    def vote() {
//        if (session.u){}
//    }
}

