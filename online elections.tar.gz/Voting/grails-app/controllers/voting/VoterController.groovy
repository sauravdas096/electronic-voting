package voting

class VoterController {

//   def index() {
//        if (session.u) {}
//    }
//
//    def create() {
//        if (session.u) {
//            Voters voteinstance = new Voters()
//            voteinstance.Name = params.Name
//            voteinstance.Collegeid = params.Collegeid
//            voteinstance.Password = params.Password
//            voteinstance.st = 0
//            voteinstance.p = 0
//            voteinstance.vp = 0
//		    voteinstance.s = 0
//    		voteinstance.js = 0
//            voteinstance.save(flush: true)
//            redirect action: "index"
//        }
//    }



    def login() {
    }

    def logined() {

            Voters voteinstance = Voters.findByCollegeidAndPassword(params.collegeid, params.pass)

        if (voteinstance) {

            session.mySession = voteinstance.id
            
            if (voteinstance.st == 0) {
                if (voteinstance) {
                    session["Voter"] = voteinstance
                    flash.myMessage = "login successfully"
                    redirect(controller: "Voter", action: "vote")
                }
            } else {
                redirect action: "login"
            }
        }
    }

    def logout(long id) {
        if (session.mySession) {
            def a = Voters.get(id)
            a.st = a.st + 1
            a.save(flush: true)
            session.invalidate()
            redirect(action: "login")

        }
    }

    def President(long id) {
        if (session.mySession) {
	    println(params)
            Voters inst = Voters.findById(params.id)
	    println(inst)
          
            if (inst) {
                [President: President.list()]
            }
        }
    }

    def SavePresident(long id) {
        if (session.mySession) {
            def pre = President.get(id)
            pre.count = pre.count + 1
            pre.save(flush: true)
            def xyz = Voters.get(id)
            xyz.p = xyz.p + 1
            xyz.save(flush: true)
            println "pre.count"
            redirect(action: "login")
        }
    }

    def VicePresident(long id) {
        if (session.mySession) {
            Voters inst =  Voters.findById(params.id)
            if (inst.vp == 0) {
                [VicePresident: VicePresident.list()]
            }
        }
    }

    def SaveVicePresident(long id) {
        if (session.mySession) {
            def pre = VicePresident.get(id)
            pre.count = pre.count + 1
            pre.save(flush: true)
            def xyz = Voters.get(id)
            xyz.vp = xyz.vp + 1
            xyz.save(flush: true)
            println "pre.count"
            redirect(action: "login")
        }
    }

    def Secretary(long id) {
        if (session.mySession) {
            Voters inst = Voters.findById(params.id)
            if (inst.s == 0) {
                [Secretary: Secretary.list()]
            }
        }
    }

    def SaveSecretary(long id) {
        if (session.mySession) {
            def pre = Secretary.get(id)
            pre.count = pre.count + 1
            pre.save(flush: true)
            def xyz = Voters.get(id)
            xyz.s = xyz.s + 1
            xyz.save(flush: true)
            println "pre.count"
            redirect(action: "login")
        }
    }

    def JointSecretary(long id) {
        if (session.mySession) {
            Voters inst  = Voters.findById(params.id)
            if (inst.js == 0) {
                [JointSecretary: JointSecretary.list()]
            }
        }
    }

    def SaveJointSecretary(long id) {
        if (session.mySession) {
            def pre = JointSecretary.get(id)
            pre.count = pre.count + 1
            pre.save(flush: true)
            def xyz = Voters.get(id)
            xyz.js = xyz.js + 1
            xyz.save(flush: true)
            println "pre.count"
            redirect(action: "login")
        }
    }
    def vote(){
        if (session.mySession){

        }
    }
}
