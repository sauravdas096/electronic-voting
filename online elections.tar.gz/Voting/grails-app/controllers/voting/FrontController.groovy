package voting

class FrontController {

    def index() { }
}
