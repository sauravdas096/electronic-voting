package voting

class BootStrap {

    def init = { servletContext ->

        Admin a1 = new Admin(Username : "abc@example.com",Password : "abc");
        a1.save()

    }
    def destroy = {
    }
}
