package voting

class Admin {
    String Username
    String Password
    static constraints = {
    }
}
