package voting

class VicePresident {
    String name2
    int id
    String age2
    String add2
    int count

    static constraints = {
    }
}
