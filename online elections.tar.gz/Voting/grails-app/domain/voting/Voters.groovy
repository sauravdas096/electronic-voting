package voting

class Voters {
        int id
        String Name
        String collegeid
        String password
        int st
        int p
        int vp
        int s
        int js
    static constraints = {
    }
}
