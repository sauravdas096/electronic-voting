package voting

class Secretary {
    String name3
    int id
    String age3
    String add3
    int count

    static constraints = {
    }
}
