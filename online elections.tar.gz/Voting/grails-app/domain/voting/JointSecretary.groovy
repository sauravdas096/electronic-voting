package voting

class JointSecretary {
    String name4
    int id
    String age4
    String add4
    int count

    static constraints = {
    }
}
