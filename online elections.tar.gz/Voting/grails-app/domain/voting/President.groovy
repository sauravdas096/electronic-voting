package voting

class President {
    String name1
    String age1
    int id
    String add1
    int count

    static constraints = {
    }
}
